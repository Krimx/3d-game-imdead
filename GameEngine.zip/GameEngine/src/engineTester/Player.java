package engineTester;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector3f;

import entities.Camera;
import toolbox.Maths;

public class Player {
	private float x,y,z;
	private float width, height;
	private Head head;
	private float walkSpeed, runSpeed, sensititivy, lockPitch, maxLookAround;
	private float vForward,vy,vSide;
	private float jumpPower, gravity, acceleration;
	private BoundingBox hitbox, downBox, upBox, leftBox, rightBox, forwardBox, backBox, blockHitbox;
	private boolean downCol, upCol, leftCol, rightCol, forwardCol, backCol;
	private int coyoteTimer, coyote;
	private boolean coyotePassed;
	
	public float getX() {return x;}
	public void setX(float x) {this.x = x;}
	public float getY() {return y;}
	public void setY(float y) {this.y = y;}
	public float getZ() {return z;}
	public void setZ(float z) {this.z = z;}
	public Head getHead() {return head;}
	public void setHead(Head head) {this.head = head;}

	public float getMaxlookAround() {return this.maxLookAround;}
	public void setMaxLookAround(float maxLookAround) {this.maxLookAround = maxLookAround;}

	public Player() {
		this(0,0,0,2,3,0,0,0);
	}
	
	public Player(float x, float y, float z, float width, float height, float pitch, float yaw, float roll) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.width = width;
		this.height = height;
		
		this.head = new Head(pitch, yaw, roll);
		
		this.walkSpeed = 0.15f;
		this.runSpeed = 0.21f;
		this.acceleration = 0.03f;
		this.lockPitch = 90f;
		this.sensititivy = 0.12f;
		this.maxLookAround = 250;
		this.coyoteTimer = 10;
		this.coyote = this.coyoteTimer;
		this.coyotePassed = false;
		
		this.vForward = 0;
		this.vy = 0;
		this.vSide = 0;
		
		this.jumpPower = 0.22f;
		this.gravity = 0.017f;
		this.downCol = false;
		this.upCol = false;
		this.leftCol = false;
		this.rightCol = false;
		this.forwardCol = false;
		this.backCol = false;

		this.hitbox = new BoundingBox(this.x, this.y, this.z, this.width, this.height, this.width);
		this.downBox = new BoundingBox(this.x, this.y - (this.height / 2), this.z, this.width, 0.02f, this.width);
		this.upBox = new BoundingBox(this.x, this.y + (this.height / 2), this.z, this.width, 0.02f, this.width);
		this.leftBox = new BoundingBox(this.x - (this.width / 2), this.y, this.z, 0.02f, this.height, this.width);
		this.rightBox = new BoundingBox(this.x + (this.width / 2), this.y, this.z, 0.02f, this.height, this.width);
		this.forwardBox = new BoundingBox(this.x, this.y, this.z - (this.width / 2), this.width, this.height, 0.02f);
		this.backBox = new BoundingBox(this.x, this.y, this.z + (this.width / 2), this.width, this.height, 0.02f);
		this.blockHitbox = new BoundingBox(this.x, this.y, this.z, this.width + 0.02f, this.height + 0.02f, this.width + 0.02f);
	}
	
	class Head {
		private float pitch, yaw, roll;
		private float x,y,z;
		
		public Head(float pitch, float yaw, float roll) {
			this.pitch = pitch;
			this.yaw = yaw;
			this.roll = roll;
		}

		public float getPitch() {return pitch;}
		public void setPitch(float pitch) {this.pitch = pitch;}
		public float getYaw() {return yaw;}
		public void setYaw(float yaw) {this.yaw = yaw;}
		public float getRoll() {return roll;}
		public void setRoll(float roll) {this.roll = roll;}
		public float getX() {return this.x;}
		public float getY() {return this.y;}
		public float getZ() {return this.z;}
		
		public void update(float x, float y, float z) {
			this.x = x;
			this.y = y;
			this.z = z;
		}
		
		public void calculatePitch(float dy, boolean alwaysActive, float sensitivity, float lockPitch) {
			if (Mouse.isButtonDown(1) || alwaysActive) {
				float pitchChange = dy * sensitivity;
				this.pitch -= pitchChange;
				
				if (lockPitch > 0) {
					if (this.pitch < -lockPitch) this.pitch = -lockPitch;
					if (this.pitch > lockPitch) this.pitch = lockPitch;
				}
			}
		}
		
		public void calculateYaw(float dx, boolean alwaysActive, float sensitivity) {
			if (Mouse.isButtonDown(1) || alwaysActive) {
				float yawChange = dx * sensitivity;
				this.yaw += yawChange;
			}
		}
		
		public void lookAround(float dx, float dy, boolean alwaysActive, float sensitivity, float lockPitch) {
			calculatePitch(dy, alwaysActive, sensitivity, lockPitch);
			calculateYaw(dx, alwaysActive, sensitivity);
		}
	}
	
	public void update(float mouseDX, float mouseDY, ArrayList<Block> blocks) {
		lookAround(mouseDX, mouseDY);
		this.head.update(this.x, this.y + (this.height / 2.0f), this.z);
		
		gravity(blocks);
		
		//Jumping
		if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
			if (downCol || (this.coyote > 0 && !this.coyotePassed)) {
				downCol = false;
				this.vy = this.jumpPower;
				this.coyotePassed = true;
			}
		}

		moveWithVelocity(blocks);
	}
	
	public void snapToBlocks(ArrayList<Block> blocks) {
		float shiftAmount = 0.01f;
		for (Block block : getCollidableBlocks(blocks)) {
			while (this.hitbox.getDirCollision(block.getHitbox()) == BoundingBox.down_collision) {
				this.y += shiftAmount;
				updateHitboxes();
			}
		}
	}
	
	public void gravity(ArrayList<Block> blocks) {
		updateHitboxes();
		checkCollision(getCollidableBlocks(blocks));
		for (float i = 0; i < Math.abs(this.vy); i += 0.01f) {
			i = Math.round(i * 100.0f) / 100.0f;
			if (this.vy > 0 && !this.upCol) this.y += 0.01f;
			if (this.vy < 0 && !this.downCol) this.y -= 0.01f;
			this.y = Math.round(this.y * 100.0f) / 100.0f;
			updateHitboxes();
			checkCollision(getCollidableBlocks(blocks));
		}
		if (!this.downCol) {
			this.vy -= this.gravity;
			if (this.coyote > 0) this.coyote--;
		}
		else {
			if (this.vy < 0) this.vy = 0;
			this.coyote = this.coyoteTimer;
			this.coyotePassed = false;
		}
		this.vy = Math.round(this.vy * 100.0f) / 100.0f;
		
		/*
		float margin = 0.01f;
		for (float i = 0; i < Math.abs(this.vy); i += margin) {
			if (this.vy > 0 && !this.upCol) this.y += margin;
			if (this.vy < 0 && !this.downCol) this.y -= margin;
			updateHitboxes();
			checkCollision(blocks);
		}
		*/
		
		
		//snapToBlocks(blocks);
	}
	
	public void checkCollision(ArrayList<Block> blocks) {
		this.downCol = false;
		this.upCol = false;
		this.leftCol = false;
		this.rightCol = false;
		this.forwardCol = false;
		this.backCol = false;
		
		updateHitboxes();
		
		for (Block block : getCollidableBlocks(blocks)) {
			if (this.blockHitbox.getDirCollision(block.getHitbox()) == BoundingBox.down_collision) this.downCol = true;
			if (this.blockHitbox.getDirCollision(block.getHitbox()) == BoundingBox.up_collision) this.upCol = true;
			if (this.blockHitbox.getDirCollision(block.getHitbox()) == BoundingBox.left_collision) this.leftCol = true;
			if (this.blockHitbox.getDirCollision(block.getHitbox()) == BoundingBox.right_collision) this.rightCol = true;
			if (this.blockHitbox.getDirCollision(block.getHitbox()) == BoundingBox.forward_collision) this.forwardCol = true;
			if (this.blockHitbox.getDirCollision(block.getHitbox()) == BoundingBox.back_collision) this.backCol = true;
		}
	}
	
	public void updateHitboxes() {
		this.hitbox.update(this.x, this.y, this.z, this.width, this.height, this.width);
		this.downBox.update(this.x, this.y - (this.height / 2), this.z, this.width, 0.02f, this.width);
		this.upBox.update(this.x, this.y + (this.height / 2), this.z, this.width, 0.02f, this.width);
		this.leftBox.update(this.x - (this.width / 2), this.y, this.z, 0.02f, this.height, this.width);
		this.rightBox.update(this.x + (this.width / 2), this.y, this.z, 0.02f, this.height, this.width);
		this.forwardBox.update(this.x, this.y, this.z - (this.width / 2), this.width, this.height, 0.02f);
		this.backBox.update(this.x, this.y, this.z + (this.width / 2), this.width, this.height, 0.02f);
		this.blockHitbox.update(this.x, this.y, this.z, this.width + 0.02f, this.height + 0.02f, this.width + 0.02f);
	}
	
	public void moveWithVelocity(ArrayList<Block> blocks) {
		boolean W = false, A = false, S = false, D = false, F = false;
		float toZeroThres = 0.02f;
		if (Keyboard.isKeyDown(Keyboard.KEY_W)) W = true;
		if (Keyboard.isKeyDown(Keyboard.KEY_S)) S = true;
		if (Keyboard.isKeyDown(Keyboard.KEY_D)) D = true;
		if (Keyboard.isKeyDown(Keyboard.KEY_A)) A = true;
		if (Keyboard.isKeyDown(Keyboard.KEY_F)) F = true;
		
		if (W) {
			if (this.vForward < this.walkSpeed) this.vForward += this.acceleration;
			//Running if holding F
			
			if (F) {
				if (this.vForward < this.runSpeed) this.vForward += this.acceleration;
			}
			
		}
		if (S) if (this.vForward > -this.walkSpeed) this.vForward -= this.acceleration;
		if ((W && S) || (!W && !S)) this.vForward = 0;

		if (A) if (this.vSide < this.walkSpeed) this.vSide += this.acceleration;
		if (D) if (this.vSide > -this.walkSpeed) this.vSide -= this.acceleration;
		if ((A && D) || (!A && !D)) this.vSide = 0;
		
		this.vForward = Math.round(this.vForward * 100.0f) / 100.0f;
		this.vSide = Math.round(this.vSide * 100.0f) / 100.0f;

		float dz = 0, dx = 0;
		if ((W || S) && (A || D)) {
			dz = (float) -(Math.cos(Math.toRadians(-this.head.getYaw())) * this.vForward);
			dx = (float) -(Math.sin(Math.toRadians(-this.head.getYaw())) * this.vForward);
			dz += (float) -(Math.sin(Math.toRadians(this.head.getYaw())) * this.vSide);
			dx += (float) -(Math.cos(Math.toRadians(this.head.getYaw())) * this.vSide);
			BoundingBox xBox = new BoundingBox(this.x + dx, this.y, this.z, this.width, this.height - 0.5f, this.width);
			BoundingBox zBox = new BoundingBox(this.x, this.y, this.z + dz, this.width, this.height - 0.5f, this.width);
			ArrayList<Block> colls = getCollidableBlocks(blocks);
			
			boolean canX = true;
			boolean canZ = true;
			updateHitboxes();
			colls = getCollidableBlocks(blocks);
			
			for (Block block : colls) {
				if (xBox.isColliding(block.getHitbox())) canX = false;
				if (zBox.isColliding(block.getHitbox())) canZ = false;
			}
			if (canX) this.x += dx;
			else {
				//TODO: Make it so the player can get up next to a block if the test fails
				float shift = 0.01f;
				if (dx < 0) shift = -shift;
				for (int i = 0; i < 20; i++) {
					BoundingBox testBox = new BoundingBox(this.x + shift, this.y, this.z, this.width, this.height - 0.5f, this.width);
					
					boolean testCol = false;
					updateHitboxes();
					for (Block block : colls) {
						if (testBox.isColliding(block.getHitbox())) testCol = true;
					}
					if (!testCol) this.x += shift;
					else break;
				}
			}
			
			updateHitboxes();
			colls = getCollidableBlocks(blocks);
			if (canZ) this.z += dz;
			else {
				float shift = 0.01f;
				if (dz < 0) shift = -shift;
				for (int i = 0; i < 20; i++) {
					BoundingBox testBox = new BoundingBox(this.x, this.y, this.z + shift, this.width, this.height - 0.5f, this.width);
					
					boolean testCol = false;
					updateHitboxes();
					for (Block block : colls) {
						if (testBox.isColliding(block.getHitbox())) testCol = true;
					}
					if (!testCol) this.z += shift;
					else break;
				}
			}
		}
		else if (W || S) {
			dz = (float) -(Math.cos(Math.toRadians(-this.head.getYaw())) * this.vForward);
			dx = (float) -(Math.sin(Math.toRadians(-this.head.getYaw())) * this.vForward);
			BoundingBox xBox = new BoundingBox(this.x + dx, this.y, this.z, this.width, this.height - 0.5f, this.width);
			BoundingBox zBox = new BoundingBox(this.x, this.y, this.z + dz, this.width, this.height - 0.5f, this.width);
			ArrayList<Block> colls = getCollidableBlocks(blocks);
			boolean canX = true;
			boolean canZ = true;
			for (Block block : colls) {
				if (xBox.isColliding(block.getHitbox())) canX = false;
				if (zBox.isColliding(block.getHitbox())) canZ = false;
			}
			if (canX) this.x += dx;
			if (canZ) this.z += dz;
		}
		else if (A || D) {
			dz = (float) -(Math.sin(Math.toRadians(this.head.getYaw())) * this.vSide);
			dx = (float) -(Math.cos(Math.toRadians(this.head.getYaw())) * this.vSide);
			BoundingBox xBox = new BoundingBox(this.x + dx, this.y, this.z, this.width, this.height - 0.5f, this.width);
			BoundingBox zBox = new BoundingBox(this.x, this.y, this.z + dz, this.width, this.height - 0.5f, this.width);
			ArrayList<Block> colls = getCollidableBlocks(blocks);
			boolean canX = true;
			boolean canZ = true;
			for (Block block : colls) {
				if (xBox.isColliding(block.getHitbox())) canX = false;
				if (zBox.isColliding(block.getHitbox())) canZ = false;
			}
			if (canX) this.x += dx;
			if (canZ) this.z += dz;
			else {
				//TODO: Come up with some way to allow the player to get up close with a block
			}
		}
		
		updateHitboxes();
	}
	
	public ArrayList<Block> getCollidableBlocks(ArrayList<Block> blocks) {
		ArrayList<Block> collidables = new ArrayList<>();
		
		//TODO: Donts use a distance formula but instead use the bounds of the hitbox. The distance formula is just being used as a quickfix
		for (Block block : blocks) {
			if (Maths.distance(new Vector3f(this.x, this.y, this.z), block.getPos()) <= this.height * .8f) {
				collidables.add(block);
			}
		}
		
		return collidables;
	}
	
	public void makeHorizVels() {
		
	}
	
	public void lookAround(float dx, float dy) {
		this.head.lookAround(dx, dy, true, sensititivy, lockPitch);
	}
	
	public void lockCamera(Camera camera) {
		camera.setPitch(this.head.getPitch());
		camera.setYaw(this.head.getYaw());
		camera.setRoll(this.head.getRoll());
		camera.setPosition(new Vector3f(this.head.getX(), this.head.getY(), this.head.getZ()));
	}
}
