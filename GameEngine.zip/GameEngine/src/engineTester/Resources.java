package engineTester;

import renderEngine.Loader;
import textures.ModelTexture;

public class Resources {
	public ModelTexture checkerTexture, butterflyTexture;
	
	public Resources(Loader loader) {
		checkerTexture =  new ModelTexture(loader.loadTexture("checker"));
		butterflyTexture =  new ModelTexture(loader.loadTexture("butterfly"));
	}
}
