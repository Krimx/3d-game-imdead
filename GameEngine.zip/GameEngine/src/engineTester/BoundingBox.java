package engineTester;


public class BoundingBox {
	private float x,y,z,width,height,depth;
	private float l,r,f,b,u,d;

	public static int down_collision = 0;
	public static int right_collision = 1;
	public static int up_collision = 2;
	public static int left_collision = 3;
	public static int forward_collision = 4;
	public static int back_collision = 5;
	public static int no_collision = -1;

	public BoundingBox(float x, float y, float z, float width, float height, float depth) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.width = width;
		this.height = height;
		this.depth = depth;

		this.l = this.x - (this.width / 2.0f);
		this.r = this.x + (this.width / 2.0f);
		this.f = this.z - (this.depth / 2.0f);
		this.b = this.z + (this.depth / 2.0f);
		this.u = this.y + (this.height / 2.0f);
		this.d = this.y - (this.height / 2.0f);
	}
	
	public BoundingBox(BoundingBox template) {
		this.x = template.getX();
		this.y = template.getY();
		this.z = template.getZ();
		this.width = template.getWidth();
		this.height = template.getHeight();
		this.depth = template.getDepth();

		this.l = this.x - (this.width / 2.0f);
		this.r = this.x + (this.width / 2.0f);
		this.f = this.z - (this.depth / 2.0f);
		this.b = this.z + (this.depth / 2.0f);
		this.u = this.y + (this.height / 2.0f);
		this.d = this.y - (this.height / 2.0f);
	}
	
	public BoundingBox getClone() {
		return new BoundingBox(this.x, this.y, this.z, this.width, this.height, this.depth);
	}

	public float getX() {return x;}
	public void setX(float x) {this.x = x;}
	public float getY() {return y;}
	public void setY(float y) {this.y = y;}
	public float getZ() {return z;}
	public void setZ(float z) {this.z = z;}
	public float getWidth() {return width;}
	public void setWidth(float width) {this.width = width;}
	public float getHeight() {return height;}
	public void setHeight(float height) {this.height = height;}
	public float getDepth() {return depth;}
	public void setDepth(float depth) {this.depth = depth;}
	public float getLeft() {return this.l;}
	public float getRight() {return this.r;}
	public float getForward() {return this.f;}
	public float getBack() {return this.b;}
	public float getUp() {return this.u;}
	public float getDown() {return this.d;}
	
	public void update(float x, float y, float z, float width, float height, float depth) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.width = width;
		this.height = height;
		this.depth = depth;

		this.l = this.x - (this.width / 2.0f);
		this.r = this.x + (this.width / 2.0f);
		this.f = this.z - (this.depth / 2.0f);
		this.b = this.z + (this.depth / 2.0f);
		this.u = this.y + (this.height / 2.0f);
		this.d = this.y - (this.height / 2.0f);
	}
	
	public int getDirCollision(BoundingBox b) {
		int dir = -1;
		if (b == null) return dir;
		else {
			if (isColliding(b)) {
				
				float margin = 0;
				float marginChange = 0.05f;
				while (true) {
					BoundingBox temp;
					
					temp = new BoundingBox(this.x, this.y + margin, this.z, this.width, this.height, this.depth);
					if (!isColliding(temp, b)) {
						dir = 0;
						break;
					}
					
					temp = new BoundingBox(this.x + margin, this.y, this.z, this.width, this.height, this.depth);
					if (!isColliding(temp, b)) {
						dir = 1;
						break;
					}

					temp = new BoundingBox(this.x, this.y - margin, this.z, this.width, this.height, this.depth);
					if (!isColliding(temp, b)) {
						dir = 2;
						break;
					}

					temp = new BoundingBox(this.x - margin, this.y, this.z, this.width, this.height, this.depth);
					if (!isColliding(temp, b)) {
						dir = 3;
						break;
					}

					temp = new BoundingBox(this.x, this.y, this.z - margin, this.width, this.height, this.depth);
					if (!isColliding(temp, b)) {
						dir = 4;
						break;
					}

					temp = new BoundingBox(this.x, this.y, this.z + margin, this.width, this.height, this.depth);
					if (!isColliding(temp, b)) {
						dir = 5;
						break;
					}
					
					margin += marginChange;
					margin = round(margin);
				}
			}
		}

		
		
		return dir;
	}
	
	public float round(float in) {
		return Math.round(in * 100.0f) / 100.0f;
	}
	
	public boolean isColliding (BoundingBox b) {
		if (b == null) return false;
		else {
			if (
					(this.l <= b.getRight()) &&
					(this.r >= b.getLeft()) &&
					(this.f <= b.getBack()) &&
					(this.b >= b.getForward()) &&
					(this.d <= b.getUp()) &&
					(this.u >= b.getDown())) {
				return true;
			}
			
			else {
				return false;
			}
		}
	}
	
	public boolean isColliding (BoundingBox a, BoundingBox b) {
		if (b == null) return false;
		else {
			if (
					(a.getLeft() <= b.getRight()) &&
					(a.getRight() >= b.getLeft()) &&
					(a.getForward() <= b.getBack()) &&
					(a.getBack() >= b.getForward()) &&
					(a.getDown() <= b.getUp()) &&
					(a.getUp() >= b.getDown())) {
				return true;
			}
			
			else {
				return false;
			}
		}
	}
}