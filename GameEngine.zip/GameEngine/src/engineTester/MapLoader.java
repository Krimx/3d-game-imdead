package engineTester;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import entities.Entity;
import renderEngine.Loader;

public class MapLoader {
	public static void loadMap(ArrayList<Block> blocks, String fileName, Loader loader, Resources recs, ArrayList<Entity> entities) {
		try {
			Scanner reader = new Scanner(new File("res/loads/" + fileName + ".map"));
			
			//Count the amount of lines and cells for relavant offsets
			int lines = 0;
			int cells = 0;
			boolean countCells = true;
			while (reader.hasNextLine()) {
				lines++;
				Scanner line = new Scanner(reader.nextLine());
				if (countCells) {
					
					while (line.hasNext()) {
						cells++;
						line.next();
					}
					countCells = false;
				}
				
			}
			
			reader = new Scanner(new File("res/loads/" + fileName + ".map"));
			
			//Actually read the data
			int xCtr = -(cells / 2);
			int yCtr = -(lines / 2);
			while (reader.hasNextLine()) {
				Scanner line = new Scanner(reader.nextLine());
				while (line.hasNext()) {
					float yPos = Float.valueOf(line.next());
					blocks.add(new Block((float)xCtr, yPos, (float)yCtr, 1, 1, 1, loader, entities, recs, false));
					xCtr++;
				}
				xCtr = -(cells / 2);
				yCtr++;
			}
			
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
