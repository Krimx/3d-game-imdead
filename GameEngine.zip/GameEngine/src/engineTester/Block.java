package engineTester;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import entities.Entity;
import models.RawModel;
import models.TexturedModel;
import objConverter.ModelData;
import objConverter.OBJFileLoader;
import objConverter.Vertex;
import renderEngine.Loader;
import textures.ModelTexture;

public class Block {
	private float x,y,z,w,h,d;
	private BoundingBox hitbox;

	private TexturedModel staticModel;
	private ModelTexture texture;
	private int entityIndex;
	
	public Block(float x, float y, float z, float w, float h, float d, Loader loader, ArrayList<Entity> entities, Resources recs, boolean cubeWrap) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
		this.h = h;
		this.d = d;
		this.hitbox = new BoundingBox(x,y,z,w,h,d);
		ModelData data = OBJFileLoader.loadOBJ("cube");

		for (int i = 0; i < data.getVertices().length; i += 3) {
			data.getVertices()[i] *= this.w / 2;
		}
		for (int i = 1; i < data.getVertices().length; i += 3) {
			data.getVertices()[i] *= this.h / 2;
		}
		for (int i = 2; i < data.getVertices().length; i += 3) {
			data.getVertices()[i] *= this.d / 2;
		}
		RawModel model = loader.loadToVAO(data.getVertices(), data.getTextureCoords(), data.getNormals(), data.getIndices());
		this.staticModel = new TexturedModel(model, recs.butterflyTexture);
		this.texture = staticModel.getTexture();
		texture.setShineDamper(0f);
		texture.setReflectivity(0f);

		Entity entity = new Entity(staticModel, new Vector3f(this.x, this.y, this.z), 0,0,0, 1);
		
		entityIndex = entities.size();
		entities.add(entity);
		
		
		
	}
	public int getEntityIndex() {return this.entityIndex;}
	public float getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public float getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public float getZ() {
		return z;
	}
	public void setZ(int z) {
		this.z = z;
	}
	public float getW() {
		return w;
	}
	public void setW(int w) {
		this.w = w;
	}
	public float getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	public float getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}
	public BoundingBox getHitbox() {
		return hitbox;
	}
	public void setHitbox(BoundingBox hitbox) {
		this.hitbox = hitbox;
	}
	public Vector3f getPos() {return new Vector3f(this.x, this.y, this.z);}
}
